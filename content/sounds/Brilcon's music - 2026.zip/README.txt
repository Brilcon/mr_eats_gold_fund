Brilcon's music - 2026

Created by:
Brilcon

License:
Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)

You are free to:
- share these sounds;
- use them in your projects;
- modify and adapt them.

Under the following conditions:
- you must give appropriate credit to the creator;
- you may not use these sounds for commercial purposes.

Attribution example:

"Music by Brilcon / Mr. Eat's Gold Fund"

Full license:
https://creativecommons.org/licenses/by-nc/4.0/

==
Contact: brilcon.mr.eat@gmail.com